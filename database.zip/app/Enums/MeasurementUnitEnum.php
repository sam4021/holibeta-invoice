<?php

namespace App\Enums;

enum MeasurementUnitEnum:string
{

    case Kgs='Kgs';
    case Grams='Grams';
}
