<?php

namespace App\Enums;

enum RoleEnum:string
{
case Admin='Admin';
case Supervisor='Supervisor';
case MachineOperator='Machine Operator';
}
