<?php

namespace App\Enums;

enum StatusEnum: string
{

    case Enabled='Enabled';
    case Disabled='Disabled';
}
